%Kyle Baylous SBU ID: 111374388
function [choice]=fn_PI_menu
%This function generates a menu for the user in order to investigate pi

choice=menu('Choose a Method to Investigate Pi','Machin''s formula','Leibniz Method','Quit');

end

