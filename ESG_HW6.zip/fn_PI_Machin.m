%Kyle Baylous SBU ID: 111374388
function fn_PI_Machin
%This function prints the result from Machin's formula


x=4*atan(1/5)-atan(1/239);

fprintf('By using Machin''s formula, pi divided by 4 is approximately %.8f\n',x)
fprintf('Therefore, pi can be approximated as %.8f\n',x*4)
end

